#include <gtk/gtk.h>
#include <stdio.h>
#include "complementario.h"
#include <stdlib.h>


typedef struct {
    GtkWidget *lbl_clave;
    GtkWidget *label5;
} app_widgets;

///////////////////////////////Funciones locales///////////////////////////////////// 

//////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[])
{
    GtkBuilder      *builder; 
    GtkWidget       *window;
      
    // instantiate structure, allocating memory for it
    app_widgets     *widgets = g_slice_new(app_widgets);
    
    buffer_clave.indice_lectura=5;//uso para probar escritura en buffer
 
    gtk_init(&argc, &argv);
 
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "glade/menu.glade", NULL);
 
    window = GTK_WIDGET(gtk_builder_get_object(builder,"window1"));
    // get pointers to the label
    widgets->lbl_clave = GTK_WIDGET(gtk_builder_get_object(builder, "lbl_clave"));
    // widgets pointer will be passed to all widget handler functions as the user_data parameter
    gtk_builder_connect_signals(builder,widgets);
 
    g_object_unref(builder);
 
    gtk_widget_show(window);                
    
    gtk_main();
    escribir_buffer();
    
    
    // reclaim memory from application after it exits
    g_slice_free(app_widgets, widgets);
 
    return 0;
}

void on_button1_clicked(GtkButton *button1,app_widgets *app_wdgts)
{
   
   gtk_label_set_text(GTK_LABEL(app_wdgts->lbl_clave),"1");
   printf("%d\r\n",buffer_clave.indice_lectura);//para probar escritura en buffer
   escribir_buffer();
}
 
// called when window is closed
void on_window1_destroy()
{
    gtk_main_quit();
}
/////////////////////////////////////////////////////////////////



