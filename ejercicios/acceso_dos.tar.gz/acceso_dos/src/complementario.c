#include "complementario.h"


void escribir_buffer()
{
	
}
